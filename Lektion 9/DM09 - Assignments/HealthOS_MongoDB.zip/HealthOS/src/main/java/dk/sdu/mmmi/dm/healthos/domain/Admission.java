package dk.sdu.mmmi.dm.healthos.domain;

/**
 * @author Oliver Nordestgaard | olnor18
 */

public class Admission {

}
